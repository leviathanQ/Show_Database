create definer = CSC174023@`%` trigger on_Insert
    before insert
    on show_table
    for each row
BEGIN
        IF new.name IN (SELECT name FROM show_table WHERE name = new.name)
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'That name is already taken';
        END IF;
    END;

