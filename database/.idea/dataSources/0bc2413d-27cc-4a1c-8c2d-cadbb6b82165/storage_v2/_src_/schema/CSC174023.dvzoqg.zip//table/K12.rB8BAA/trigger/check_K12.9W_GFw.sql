create definer = CSC174023@`%` trigger check_K12
    before insert
    on K12
    for each row
BEGIN
        IF NEW.SID IN (SELECT COLLEGE.SID FROM COLLEGE WHERE COLLEGE.SID = new
            .SID)
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'This SID is already in college';
        END IF;
    END;

