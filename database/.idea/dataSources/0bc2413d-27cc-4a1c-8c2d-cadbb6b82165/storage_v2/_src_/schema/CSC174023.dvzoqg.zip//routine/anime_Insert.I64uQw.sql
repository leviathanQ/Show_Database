create
    definer = CSC174023@`%` procedure anime_Insert(IN show_Name varchar(255),
                                                   IN ani_Season enum ('Spring', 'Summer', 'Fall', 'Winter'),
                                                   IN ani_Year int)
BEGIN
        INSERT INTO show_table (name, show_Type, anime_Season, anime_Year) VALUES
        (show_Name, 'Anime', ani_Season, ani_Year);
    end;

