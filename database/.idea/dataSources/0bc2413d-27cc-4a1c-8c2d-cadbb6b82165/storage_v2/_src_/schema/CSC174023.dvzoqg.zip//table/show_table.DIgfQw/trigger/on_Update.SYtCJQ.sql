create definer = CSC174023@`%` trigger on_Update
    before update
    on show_table
    for each row
BEGIN
        IF new.name IN (SELECT name FROM show_table WHERE name = new.name
                                                    AND show_Type = 'Anime')
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'That name is already in the table and it\'s
classified as an anime type';
        END IF;
        IF new.name IN (SELECT name FROM show_table WHERE name = new.name
                                                    AND show_Type = 'Cartoon')
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'That name is already in the table and it\'s
classified as an cartoon type';
        END IF;
    END;

