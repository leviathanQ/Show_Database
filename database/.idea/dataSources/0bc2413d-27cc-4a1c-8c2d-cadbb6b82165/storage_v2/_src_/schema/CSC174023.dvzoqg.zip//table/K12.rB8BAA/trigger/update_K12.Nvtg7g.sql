create definer = CSC174023@`%` trigger update_K12
    before update
    on K12
    for each row
BEGIN
        IF NEW.SID IN (SELECT COLLEGE.SID FROM COLLEGE WHERE COLLEGE.SID =
                                                             NEW.SID)
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Can not use this SID as it is in COLLEGE TABLE';
        END IF;
    END;

