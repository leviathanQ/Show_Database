create definer = CSC174023@`%` trigger check_COLLEGE
    before insert
    on COLLEGE
    for each row
BEGIN
        IF NEW.SID IN (SELECT K12.SID FROM K12 WHERE K12.SID = NEW.SID)
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'This SID is already in K12';
        END IF;
    END;

