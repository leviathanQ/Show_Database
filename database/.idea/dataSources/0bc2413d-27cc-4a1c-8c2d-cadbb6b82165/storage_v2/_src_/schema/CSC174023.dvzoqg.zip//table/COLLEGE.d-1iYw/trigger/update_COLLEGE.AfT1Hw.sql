create definer = CSC174023@`%` trigger update_COLLEGE
    before update
    on COLLEGE
    for each row
BEGIN
        IF NEW.SID IN (SELECT K12.SID FROM K12 WHERE K12.SID = NEW.SID)
            THEN SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Can not use this SID as it is in K12 TABLE';
        END IF;
    END;

