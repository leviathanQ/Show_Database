create
    definer = CSC174023@`%` procedure cartoon_Insert(IN show_Name varchar(255),
                                                     IN cart_Network varchar(255),
                                                     IN cart_Release int)
BEGIN
        INSERT INTO show_table (name, show_Type, carton_Network,
        cartoon_Release) VALUES (show_Name, 'Cartoon', cart_Network,
                                 cart_Release);
    end;

